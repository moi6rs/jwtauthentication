package com.ideasconnector.jwtauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtauthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
